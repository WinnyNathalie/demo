﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TA_WINNY_CARISSA
{
    public partial class frmTampilanUtama : Form
    {
        public frmTampilanUtama()
        {
            InitializeComponent();
            this.BackColor = ColorTranslator.FromHtml("#F5F7FA");
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
            this.WindowState = FormWindowState.Maximized;
            this.AutoScaleMode = AutoScaleMode.None;
            
            customizeDesign();
        }
        private void customizeDesign()
        {
            //WN ISI SEMUA PANEL CHILD
            //semua submenu masuk disini
            panelKeuangan.Visible = false;
            panelManajemenJadwal.Visible = false;
        }

        private readonly Font menuRegularFont = new Font("Roboto", 12F, FontStyle.Regular);

        private readonly Font menuBoldFont = new Font("Roboto", 12F, FontStyle.Bold);

        private void showSubmenu(Panel subMenu)
        {
            subMenu.Visible = !subMenu.Visible;
        }
        private bool IsParentExpanded(Button parentButton)
        {
            //WN ISI SEMUA PARENT
            if (parentButton == btnKeuangan)
                return panelKeuangan.Visible;

            if (parentButton == btnManajemenJadwal)
                return panelManajemenJadwal.Visible;

            return false;
        }

        private void RefreshParentStyle(Button parentButton)
        {
            if (parentButton == activeParentButton ||
                IsParentExpanded(parentButton))
            {
                SetParentActiveButton(parentButton);
            }
            else
            {
                SetDefaultButton(parentButton);
            }
        }
        private void SetupHeaderInfo()
        {
            lblJam.Text = DateTime.Now.ToString("HH:mm:ss");
            lblDay.Text = DateTime.Now.ToString("dddd");

            //INI PERLU DIGANTI LAGI NANTI
            lblUsername.Text = "Winny Nathalie";
            lblRole.Text = "Administrator";

            lblTitle.ForeColor = ColorTranslator.FromHtml("#1F2937");
          //  lblTitle.Location = new Point(155, 18);
            lblTitle.AutoSize = true;

            if (panelHeader.Controls["lineHeader"] == null)
            {
                Panel line = new Panel();
                line.Name = "lineHeader";
                line.Dock = DockStyle.Bottom;
                line.Height = 1;
                line.BackColor = ColorTranslator.FromHtml("#E5E7EB");
                panelHeader.Controls.Add(line);
            }
        }
        private void SetupLayout()
        {
            panelHeader.Dock = DockStyle.Top;
            panelContent.Dock = DockStyle.Fill;
            panelContent.BackColor = ColorTranslator.FromHtml("#F5F7FA");
            panelHeaderRight.Dock = DockStyle.Right;
        }
        private void FormMainMenu_Load(object sender, EventArgs e)
        {
            SetupHeaderInfo();
            SetupLayout();
            timerClock.Start();

        }

        private void timerClock_Tick(object sender, EventArgs e)
        {
            lblJam.Text = DateTime.Now.ToString("HH:mm:ss");
            lblHari.Text = DateTime.Now.ToString("dd MMMM yyyy");
            lblDay.Text = DateTime.Now.ToString("dddd");
        }

        private void OpenControl(UserControl control)
        {
            panelContent.Controls.Clear();
            control.Dock = DockStyle.Fill;
            panelContent.Controls.Add(control);
        }
        private Button activeButton = null;
        private Button activeParentButton = null;

        private void SetDefaultButton(Button button)
        {
            button.BackColor = Color.FromArgb(248, 249, 251);
            button.ForeColor = Color.FromArgb(15, 23, 42);
            button.Font = new Font("Roboto", 12F, FontStyle.Regular);
        }

        private void SetActiveButton(Button button)
        {
            button.BackColor = Color.FromArgb(38, 95, 156);
            button.ForeColor = Color.WhiteSmoke;
            button.Font = new Font("Roboto", 12F, FontStyle.Bold);
        }

        // Style untuk tombol Induk seperti Keuangan
        private void SetParentActiveButton(Button button)
        {
            button.BackColor = Color.FromArgb(219, 234, 254);
            button.ForeColor = Color.FromArgb(25, 33, 57);
            button.Font = new Font("Roboto", 12F, FontStyle.Bold);
        }
       
        private void SidebarButton_MouseEnter(object sender, EventArgs e)
        {
            Button button = sender as Button;

            if (button == null)
                return;

            //WN ISI SEMUA PARENT
            bool isExpandedParent =
                (button == btnKeuangan &&
                 panelKeuangan.Visible) ||
                (button == btnManajemenJadwal &&
                 panelManajemenJadwal.Visible);

            if (button != activeButton &&
                button != activeParentButton &&
                !isExpandedParent)
            {
                button.BackColor =
                    Color.FromArgb(219, 234, 254);

                button.ForeColor =
                    Color.FromArgb(25, 33, 57);
            }
        }

        private void SidebarButton_MouseLeave(object sender, EventArgs e)
        {
            Button button = sender as Button;

            if (button == null)
                return;

            if (button == activeButton)
            {
                SetActiveButton(button);
            }
            else if (button == activeParentButton ||
                     IsParentExpanded(button))
            {
                SetParentActiveButton(button);
            }
            else
            {
                SetDefaultButton(button);
            }
        }
        private void SidebarButton_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton == null)
                return;

            Button parentButton = null;

            //WN ISI SEMUA PARENT
            if (clickedButton.Parent == panelKeuangan)
            {
                parentButton = btnKeuangan;
            }
            else if (clickedButton.Parent ==
                     panelManajemenJadwal)
            {
                parentButton = btnManajemenJadwal;
            }

            Button previousParent = activeParentButton;

            // Reset tombol halaman sebelumnya
            if (activeButton != null &&
                activeButton != clickedButton)
            {
                SetDefaultButton(activeButton);
            }

            activeButton = clickedButton;
            activeParentButton = parentButton;

            SetActiveButton(activeButton);

            // Perbarui parent sebelumnya
            if (previousParent != null &&
                previousParent != parentButton)
            {
                RefreshParentStyle(previousParent);
            }

            if (parentButton != null)
            {
                // Submenu yang diklik tetap terbuka
                SetParentActiveButton(parentButton);
            }
           
            //WN ISI SEMUA CHILD SUBMENU
            switch (clickedButton.Name)
            {
                case "btnDashboard":
                    // OpenControl(new ucDashboard());
                    break;

                case "btnAkunKasBank":
                    // OpenControl(new ucAkunKasBank());
                    break;

                case "btnPembayaran":
                    // OpenControl(new ucPembayaran());
                    break;

                case "btnPenerimaan":
                    // OpenControl(new ucPenerimaan());
                    break;

                case "btnTransferBank":
                    // OpenControl(new ucTransferBank());
                    break;

                case "btnJadwal":
                    // OpenControl(new ucJadwal());
                    break;

                case "btnKelas":
                    // OpenControl(new ucKelas());
                    break;

                case "btnGrade":
                    // OpenControl(new ucGrade());
                    break;

                case "btnRuanganKelas":
                    // OpenControl(new ucRuanganKelas());
                    break;
            }
        }

        private void ToggleSubmenu(Button parentButton, Panel submenuPanel)
        {
            showSubmenu(submenuPanel);
            RefreshParentStyle(parentButton);
        }

        //WN BUAT SEMUA PARENT TOGGLE
        private void btnKeuangan_Click(object sender, EventArgs e)
        {
            ToggleSubmenu(btnKeuangan, panelKeuangan);
        }
       
        private void btnManajemenJadwal_Click(object sender, EventArgs e)
        {
            ToggleSubmenu(btnManajemenJadwal, panelManajemenJadwal);
        }


    }
}
