﻿
namespace TA_WINNY_CARISSA
{
    partial class frmTampilanUtama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTampilanUtama));
            this.panelHeader = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.panelHeaderRight = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblJam = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblDay = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblHari = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelContent = new System.Windows.Forms.Panel();
            this.timerClock = new System.Windows.Forms.Timer(this.components);
            this.btnDashboard = new System.Windows.Forms.Button();
            this.btnKeuangan = new System.Windows.Forms.Button();
            this.panelKeuangan = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnPenerimaan = new System.Windows.Forms.Button();
            this.btnPembayaran = new System.Windows.Forms.Button();
            this.btnAkunKasBank = new System.Windows.Forms.Button();
            this.btnManajemenJadwal = new System.Windows.Forms.Button();
            this.panelSideBar = new System.Windows.Forms.Panel();
            this.panelManajemenJadwal = new System.Windows.Forms.Panel();
            this.btnRuangan = new System.Windows.Forms.Button();
            this.btnGrade = new System.Windows.Forms.Button();
            this.btnKelas = new System.Windows.Forms.Button();
            this.btnJadwal = new System.Windows.Forms.Button();
            this.panelHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.panelHeaderRight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelKeuangan.SuspendLayout();
            this.panelSideBar.SuspendLayout();
            this.panelManajemenJadwal.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.panelHeader.Controls.Add(this.picLogo);
            this.panelHeader.Controls.Add(this.panelHeaderRight);
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(1366, 110);
            this.panelHeader.TabIndex = 0;
            // 
            // picLogo
            // 
            this.picLogo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
            this.picLogo.InitialImage = null;
            this.picLogo.Location = new System.Drawing.Point(25, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(133, 110);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.TabIndex = 3;
            this.picLogo.TabStop = false;
            // 
            // panelHeaderRight
            // 
            this.panelHeaderRight.Controls.Add(this.label3);
            this.panelHeaderRight.Controls.Add(this.lblUsername);
            this.panelHeaderRight.Controls.Add(this.lblRole);
            this.panelHeaderRight.Controls.Add(this.lblJam);
            this.panelHeaderRight.Controls.Add(this.pictureBox3);
            this.panelHeaderRight.Controls.Add(this.pictureBox2);
            this.panelHeaderRight.Controls.Add(this.lblDay);
            this.panelHeaderRight.Controls.Add(this.pictureBox1);
            this.panelHeaderRight.Controls.Add(this.lblHari);
            this.panelHeaderRight.Controls.Add(this.lblTime);
            this.panelHeaderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelHeaderRight.Location = new System.Drawing.Point(641, 0);
            this.panelHeaderRight.Name = "panelHeaderRight";
            this.panelHeaderRight.Size = new System.Drawing.Size(725, 110);
            this.panelHeaderRight.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Light", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(414, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 70);
            this.label3.TabIndex = 9;
            this.label3.Text = "|";
            // 
            // lblUsername
            // 
            this.lblUsername.Font = new System.Drawing.Font("Roboto", 9F, System.Drawing.FontStyle.Bold);
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.lblUsername.Location = new System.Drawing.Point(530, 27);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(176, 25);
            this.lblUsername.TabIndex = 8;
            this.lblUsername.Text = "Winny Nathalie";
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Font = new System.Drawing.Font("Roboto", 9F, System.Drawing.FontStyle.Bold);
            this.lblRole.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblRole.Location = new System.Drawing.Point(531, 52);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(123, 22);
            this.lblRole.TabIndex = 7;
            this.lblRole.Text = "Administrator";
            // 
            // lblJam
            // 
            this.lblJam.AutoSize = true;
            this.lblJam.Font = new System.Drawing.Font("Roboto", 11F, System.Drawing.FontStyle.Bold);
            this.lblJam.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.lblJam.Location = new System.Drawing.Point(291, 38);
            this.lblJam.Name = "lblJam";
            this.lblJam.Size = new System.Drawing.Size(102, 27);
            this.lblJam.TabIndex = 6;
            this.lblJam.Text = "11:12:13";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(462, 28);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 48);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(235, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(49, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // lblDay
            // 
            this.lblDay.AutoSize = true;
            this.lblDay.Font = new System.Drawing.Font("Roboto", 9F, System.Drawing.FontStyle.Bold);
            this.lblDay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.lblDay.Location = new System.Drawing.Point(91, 24);
            this.lblDay.Name = "lblDay";
            this.lblDay.Size = new System.Drawing.Size(70, 22);
            this.lblDay.TabIndex = 3;
            this.lblDay.Text = "Sunday";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(18, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(58, 54);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblHari
            // 
            this.lblHari.AutoSize = true;
            this.lblHari.Font = new System.Drawing.Font("Roboto", 9F, System.Drawing.FontStyle.Bold);
            this.lblHari.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.lblHari.Location = new System.Drawing.Point(91, 49);
            this.lblHari.Name = "lblHari";
            this.lblHari.Size = new System.Drawing.Size(113, 22);
            this.lblHari.TabIndex = 1;
            this.lblHari.Text = "17 May 2026";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(298, 39);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(103, 30);
            this.lblTime.TabIndex = 0;
            this.lblTime.Text = "11:12:13";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Roboto", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(178, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(578, 43);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "KURSUS MANDARIN JIAYOU  加油";
            // 
            // panelContent
            // 
            this.panelContent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.panelContent.Location = new System.Drawing.Point(388, 110);
            this.panelContent.Name = "panelContent";
            this.panelContent.Size = new System.Drawing.Size(978, 1060);
            this.panelContent.TabIndex = 2;
            // 
            // timerClock
            // 
            this.timerClock.Tick += new System.EventHandler(this.timerClock_Tick);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnDashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(42)))));
            this.btnDashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDashboard.Location = new System.Drawing.Point(0, 0);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(0, 20, 0, 0);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Padding = new System.Windows.Forms.Padding(20, 6, 0, 0);
            this.btnDashboard.Size = new System.Drawing.Size(385, 67);
            this.btnDashboard.TabIndex = 24;
            this.btnDashboard.Text = "   Dashboard";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDashboard.UseCompatibleTextRendering = true;
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.SidebarButton_Click);
            this.btnDashboard.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnDashboard.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // btnKeuangan
            // 
            this.btnKeuangan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnKeuangan.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnKeuangan.FlatAppearance.BorderSize = 0;
            this.btnKeuangan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKeuangan.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnKeuangan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnKeuangan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKeuangan.Location = new System.Drawing.Point(0, 67);
            this.btnKeuangan.Margin = new System.Windows.Forms.Padding(0, 12, 0, 0);
            this.btnKeuangan.Name = "btnKeuangan";
            this.btnKeuangan.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnKeuangan.Size = new System.Drawing.Size(385, 63);
            this.btnKeuangan.TabIndex = 26;
            this.btnKeuangan.Text = "   Keuangan";
            this.btnKeuangan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKeuangan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnKeuangan.UseCompatibleTextRendering = true;
            this.btnKeuangan.UseVisualStyleBackColor = false;
            this.btnKeuangan.Click += new System.EventHandler(this.btnKeuangan_Click);
            this.btnKeuangan.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnKeuangan.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // panelKeuangan
            // 
            this.panelKeuangan.Controls.Add(this.button1);
            this.panelKeuangan.Controls.Add(this.btnPenerimaan);
            this.panelKeuangan.Controls.Add(this.btnPembayaran);
            this.panelKeuangan.Controls.Add(this.btnAkunKasBank);
            this.panelKeuangan.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelKeuangan.Location = new System.Drawing.Point(0, 130);
            this.panelKeuangan.Name = "panelKeuangan";
            this.panelKeuangan.Size = new System.Drawing.Size(385, 232);
            this.panelKeuangan.TabIndex = 27;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Roboto", 12F);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 168);
            this.button1.Margin = new System.Windows.Forms.Padding(80, 3, 3, 3);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.button1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button1.Size = new System.Drawing.Size(385, 56);
            this.button1.TabIndex = 4;
            this.button1.Text = "    Transfer Bank";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.SidebarButton_Click);
            this.button1.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.button1.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // btnPenerimaan
            // 
            this.btnPenerimaan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnPenerimaan.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPenerimaan.FlatAppearance.BorderSize = 0;
            this.btnPenerimaan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPenerimaan.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnPenerimaan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnPenerimaan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPenerimaan.Location = new System.Drawing.Point(0, 112);
            this.btnPenerimaan.Margin = new System.Windows.Forms.Padding(80, 3, 3, 3);
            this.btnPenerimaan.Name = "btnPenerimaan";
            this.btnPenerimaan.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnPenerimaan.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnPenerimaan.Size = new System.Drawing.Size(385, 56);
            this.btnPenerimaan.TabIndex = 3;
            this.btnPenerimaan.Text = "    Penerimaan";
            this.btnPenerimaan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPenerimaan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPenerimaan.UseVisualStyleBackColor = false;
            this.btnPenerimaan.Click += new System.EventHandler(this.SidebarButton_Click);
            this.btnPenerimaan.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnPenerimaan.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // btnPembayaran
            // 
            this.btnPembayaran.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnPembayaran.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPembayaran.FlatAppearance.BorderSize = 0;
            this.btnPembayaran.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPembayaran.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnPembayaran.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnPembayaran.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPembayaran.Location = new System.Drawing.Point(0, 56);
            this.btnPembayaran.Margin = new System.Windows.Forms.Padding(80, 3, 3, 3);
            this.btnPembayaran.Name = "btnPembayaran";
            this.btnPembayaran.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnPembayaran.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnPembayaran.Size = new System.Drawing.Size(385, 56);
            this.btnPembayaran.TabIndex = 2;
            this.btnPembayaran.Text = "    Pembayaran";
            this.btnPembayaran.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPembayaran.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPembayaran.UseVisualStyleBackColor = false;
            this.btnPembayaran.Click += new System.EventHandler(this.SidebarButton_Click);
            this.btnPembayaran.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnPembayaran.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // btnAkunKasBank
            // 
            this.btnAkunKasBank.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnAkunKasBank.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAkunKasBank.FlatAppearance.BorderSize = 0;
            this.btnAkunKasBank.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAkunKasBank.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnAkunKasBank.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnAkunKasBank.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAkunKasBank.Location = new System.Drawing.Point(0, 0);
            this.btnAkunKasBank.Margin = new System.Windows.Forms.Padding(80, 3, 3, 3);
            this.btnAkunKasBank.Name = "btnAkunKasBank";
            this.btnAkunKasBank.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnAkunKasBank.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnAkunKasBank.Size = new System.Drawing.Size(385, 56);
            this.btnAkunKasBank.TabIndex = 1;
            this.btnAkunKasBank.Text = "    Akun Kas/Bank";
            this.btnAkunKasBank.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAkunKasBank.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAkunKasBank.UseVisualStyleBackColor = false;
            this.btnAkunKasBank.Click += new System.EventHandler(this.SidebarButton_Click);
            this.btnAkunKasBank.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnAkunKasBank.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // btnManajemenJadwal
            // 
            this.btnManajemenJadwal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnManajemenJadwal.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnManajemenJadwal.FlatAppearance.BorderSize = 0;
            this.btnManajemenJadwal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManajemenJadwal.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnManajemenJadwal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnManajemenJadwal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManajemenJadwal.Location = new System.Drawing.Point(0, 362);
            this.btnManajemenJadwal.Margin = new System.Windows.Forms.Padding(0, 12, 0, 0);
            this.btnManajemenJadwal.Name = "btnManajemenJadwal";
            this.btnManajemenJadwal.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnManajemenJadwal.Size = new System.Drawing.Size(385, 67);
            this.btnManajemenJadwal.TabIndex = 28;
            this.btnManajemenJadwal.Text = "    Manajemen Jadwal";
            this.btnManajemenJadwal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManajemenJadwal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnManajemenJadwal.UseCompatibleTextRendering = true;
            this.btnManajemenJadwal.UseVisualStyleBackColor = false;
            this.btnManajemenJadwal.Click += new System.EventHandler(this.btnManajemenJadwal_Click);
            this.btnManajemenJadwal.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnManajemenJadwal.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // panelSideBar
            // 
            this.panelSideBar.Controls.Add(this.panelManajemenJadwal);
            this.panelSideBar.Controls.Add(this.btnManajemenJadwal);
            this.panelSideBar.Controls.Add(this.panelKeuangan);
            this.panelSideBar.Controls.Add(this.btnKeuangan);
            this.panelSideBar.Controls.Add(this.btnDashboard);
            this.panelSideBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideBar.Location = new System.Drawing.Point(0, 110);
            this.panelSideBar.Name = "panelSideBar";
            this.panelSideBar.Size = new System.Drawing.Size(385, 1060);
            this.panelSideBar.TabIndex = 40;
            // 
            // panelManajemenJadwal
            // 
            this.panelManajemenJadwal.Controls.Add(this.btnRuangan);
            this.panelManajemenJadwal.Controls.Add(this.btnGrade);
            this.panelManajemenJadwal.Controls.Add(this.btnKelas);
            this.panelManajemenJadwal.Controls.Add(this.btnJadwal);
            this.panelManajemenJadwal.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelManajemenJadwal.Location = new System.Drawing.Point(0, 429);
            this.panelManajemenJadwal.Name = "panelManajemenJadwal";
            this.panelManajemenJadwal.Size = new System.Drawing.Size(385, 232);
            this.panelManajemenJadwal.TabIndex = 29;
            // 
            // btnRuangan
            // 
            this.btnRuangan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnRuangan.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRuangan.FlatAppearance.BorderSize = 0;
            this.btnRuangan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRuangan.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnRuangan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnRuangan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRuangan.Location = new System.Drawing.Point(0, 168);
            this.btnRuangan.Margin = new System.Windows.Forms.Padding(80, 3, 3, 3);
            this.btnRuangan.Name = "btnRuangan";
            this.btnRuangan.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnRuangan.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnRuangan.Size = new System.Drawing.Size(385, 56);
            this.btnRuangan.TabIndex = 4;
            this.btnRuangan.Text = "    Ruangan Kelas";
            this.btnRuangan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRuangan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRuangan.UseVisualStyleBackColor = false;
            this.btnRuangan.Click += new System.EventHandler(this.SidebarButton_Click);
            this.btnRuangan.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnRuangan.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // btnGrade
            // 
            this.btnGrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnGrade.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGrade.FlatAppearance.BorderSize = 0;
            this.btnGrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGrade.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnGrade.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnGrade.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGrade.Location = new System.Drawing.Point(0, 112);
            this.btnGrade.Margin = new System.Windows.Forms.Padding(80, 3, 3, 3);
            this.btnGrade.Name = "btnGrade";
            this.btnGrade.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnGrade.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnGrade.Size = new System.Drawing.Size(385, 56);
            this.btnGrade.TabIndex = 3;
            this.btnGrade.Text = "    Grade";
            this.btnGrade.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGrade.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnGrade.UseVisualStyleBackColor = false;
            this.btnGrade.Click += new System.EventHandler(this.SidebarButton_Click);
            this.btnGrade.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnGrade.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // btnKelas
            // 
            this.btnKelas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnKelas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnKelas.FlatAppearance.BorderSize = 0;
            this.btnKelas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKelas.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnKelas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnKelas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKelas.Location = new System.Drawing.Point(0, 56);
            this.btnKelas.Margin = new System.Windows.Forms.Padding(80, 3, 3, 3);
            this.btnKelas.Name = "btnKelas";
            this.btnKelas.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnKelas.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnKelas.Size = new System.Drawing.Size(385, 56);
            this.btnKelas.TabIndex = 2;
            this.btnKelas.Text = "    Kelas";
            this.btnKelas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKelas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnKelas.UseVisualStyleBackColor = false;
            this.btnKelas.Click += new System.EventHandler(this.SidebarButton_Click);
            this.btnKelas.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnKelas.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // btnJadwal
            // 
            this.btnJadwal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
            this.btnJadwal.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnJadwal.FlatAppearance.BorderSize = 0;
            this.btnJadwal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnJadwal.Font = new System.Drawing.Font("Roboto", 12F);
            this.btnJadwal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.btnJadwal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnJadwal.Location = new System.Drawing.Point(0, 0);
            this.btnJadwal.Margin = new System.Windows.Forms.Padding(80, 3, 3, 3);
            this.btnJadwal.Name = "btnJadwal";
            this.btnJadwal.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnJadwal.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnJadwal.Size = new System.Drawing.Size(385, 56);
            this.btnJadwal.TabIndex = 1;
            this.btnJadwal.Text = "    Jadwal";
            this.btnJadwal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnJadwal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnJadwal.UseVisualStyleBackColor = false;
            this.btnJadwal.Click += new System.EventHandler(this.SidebarButton_Click);
            this.btnJadwal.MouseEnter += new System.EventHandler(this.SidebarButton_MouseEnter);
            this.btnJadwal.MouseLeave += new System.EventHandler(this.SidebarButton_MouseLeave);
            // 
            // frmTampilanUtama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1366, 1170);
            this.Controls.Add(this.panelSideBar);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.panelHeader);
            this.Name = "frmTampilanUtama";
            this.ShowIcon = false;
            this.Text = "KURSUS MANDARIN JIAYOU 加油";
            this.TransparencyKey = System.Drawing.Color.White;
            this.Load += new System.EventHandler(this.FormMainMenu_Load);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.panelHeaderRight.ResumeLayout(false);
            this.panelHeaderRight.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelKeuangan.ResumeLayout(false);
            this.panelSideBar.ResumeLayout(false);
            this.panelManajemenJadwal.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel panelHeader;
        public System.Windows.Forms.Panel panelContent;
        public System.Windows.Forms.Label lblTitle;
        public System.Windows.Forms.Panel panelHeaderRight;
        public System.Windows.Forms.Label lblTime;
        public System.Windows.Forms.Timer timerClock;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Label lblHari;
        public System.Windows.Forms.Label lblDay;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.PictureBox pictureBox3;
        public System.Windows.Forms.Label lblUsername;
        public System.Windows.Forms.Label lblRole;
        public System.Windows.Forms.Label lblJam;
        public System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnKeuangan;
        private System.Windows.Forms.Panel panelKeuangan;
        public System.Windows.Forms.Button btnPenerimaan;
        public System.Windows.Forms.Button btnPembayaran;
        public System.Windows.Forms.Button btnAkunKasBank;
        private System.Windows.Forms.Button btnManajemenJadwal;
        private System.Windows.Forms.Panel panelSideBar;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panelManajemenJadwal;
        public System.Windows.Forms.Button btnRuangan;
        public System.Windows.Forms.Button btnGrade;
        public System.Windows.Forms.Button btnKelas;
        public System.Windows.Forms.Button btnJadwal;
    }
}

